const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 5000;

// Log all requests for debugging
app.use((req, res, next) => {
  console.log(`${req.method} ${req.url}`);
  next();
});

// Cache control headers for development (must be BEFORE static)
app.use((req, res, next) => {
  res.set('Cache-Control', 'no-cache, no-store, must-revalidate');
  res.set('Pragma', 'no-cache');
  res.set('Expires', '0');
  next();
});

// Serve static files from the current directory
app.use(express.static(path.join(__dirname), {
  setHeaders: (res, path) => {
    res.set('Cache-Control', 'no-cache, no-store, must-revalidate');
  }
}));

// Serve index.html for root path
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// 404 handler - log missing files
app.use((req, res) => {
  console.log(`404 NOT FOUND: ${req.url}`);
  res.status(404).send('Not Found');
});

// Start server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`✓ Server is running on http://0.0.0.0:${PORT}`);
  console.log(`✓ Three.js Octree Collisions Demo Ready`);
});
